#!/usr/bin/env python3
"""
backtest.py  -  Mesin backtest UTS Algorithmic Trading (Ajeng Syarafina Azzahra)
Strategi : Trend following EMA crossover + RSI + trailing stop ATR, universe Kompas100
Data     : OHLCV harian JSON (format: {"data": {TICKER: {"d":[hari-epoch], "o","h","l","c","v"}}})

ATURAN SINYAL:
  Entry : (a) EMA(F) memotong naik EMA(S) dalam 5 bar terakhir, RSI14 50-75, close > EMA(S)
          atau (b) close > tertinggi close 55 bar sebelumnya, close > EMA(F), RSI14 55-75
          (keduanya mensyaratkan EMA(F) > EMA(S)). Jika regime > 0, entry juga mensyaratkan
          benchmark equal-weight berada di atas SMA(regime). Semua sinyal dihitung dari CLOSE hari t.
  Exit  : close < (close tertinggi sejak entry) - M x ATR14  ATAU  EMA(F) < EMA(S).
          Sinyal dihitung dari CLOSE hari t.
  Eksekusi: SEMUA order diisi di OPEN bar berikutnya (t+1), tidak pernah di high/low/close.

LAPISAN EKSEKUSI REALISTIS BEI (bagian 6.D PDF):
  - fee beli 0,15% ; fee jual 0,25% (termasuk PPh final 0,1%)
  - spread: beli di offer = open + 1 fraksi; jual di bid = open - 1 fraksi
  - harga dibulatkan ke fraksi BEI ; jumlah saham kelipatan 1 lot (100 lembar)
  - likuiditas: nilai 1 order <= 5% rata-rata nilai transaksi 20 hari (s.d. close t-1 dari hari eksekusi)
  - tidak ada fill pada hari tanpa baris data / volume 0
  - ARA/ARB (proksi): bar datar (O=H=L=C) dengan |perubahan| >= 7% dianggap terkunci;
    tidak bisa beli saat terkunci naik (ARA), tidak bisa jual saat terkunci turun (ARB)
  - tanpa short selling dan tanpa margin ; keuntungan diputar kembali (compounding)
"""
import json, math, datetime
import numpy as np
from scipy.signal import lfilter

CAP = 1e8
MAXP = 10
BUY_FEE = 0.0015
SELL_FEE = 0.0025
LIQ = 0.05
LOCK_PCT = 0.07
EPOCH = datetime.date(1970, 1, 1)


def tick(p):
    return 1 if p < 200 else 2 if p < 500 else 5 if p < 2000 else 10 if p < 5000 else 25


def tick_dn(p):          # fraksi untuk harga tepat di bawah p (batas fraksi)
    return tick(p - 1e-9)


def rtick(p):
    t = tick(p)
    return max(t, round(p / t) * t)


def dstr(i):
    return str(EPOCH + datetime.timedelta(days=int(i)))


# --------------------------------------------------------------------------- data
class Data:
    def __init__(self, path, max_day=None):
        j = json.load(open(path))
        self.meta = {k: v for k, v in j.items() if k != 'data'}
        tk = sorted(j['data'])
        days = sorted(set(x for t in tk for x in j['data'][t]['d']))
        if max_day is not None:
            days = [x for x in days if x <= max_day]
        self.tk = tk
        self.epoch = np.array(days)
        self.dates = [dstr(x) for x in days]
        D, K = len(days), len(tk)
        pos = {x: i for i, x in enumerate(days)}
        self.D, self.K = D, K
        self.O, self.H, self.L, self.C, self.V = (np.full((D, K), np.nan) for _ in range(5))
        for k, t in enumerate(tk):
            r = j['data'][t]
            for f, M in zip('ohlcv', (self.O, self.H, self.L, self.C, self.V)):
                for d, v in zip(r['d'], r[f]):
                    if d in pos:
                        M[pos[d], k] = v
        self.R = ~np.isnan(self.C)                              # ada baris data
        self.TR = self.R & (np.nan_to_num(self.V) > 0)           # ada transaksi
        # close yang di-forward-fill (untuk mark-to-market saat tidak ada baris)
        Cf = self.C.copy()
        for k in range(K):
            m = np.isnan(Cf[:, k])
            idx = np.where(~m, np.arange(D), 0)
            np.maximum.accumulate(idx, out=idx)
            Cf[:, k] = Cf[idx, k]
            first = np.argmax(~m)
            Cf[:first, k] = np.nan
        self.Cf = Cf
        prev = np.vstack([np.full((1, K), np.nan), Cf[:-1]])
        ret = self.C / prev - 1
        flat = (self.O == self.H) & (self.H == self.L) & (self.L == self.C)
        self.lock_up = flat & (ret >= LOCK_PCT)                   # proksi ARA terkunci
        self.lock_dn = flat & (ret <= -LOCK_PCT)                  # proksi ARB terkunci
        # nilai transaksi harian & rata-rata 20 hari
        val = np.nan_to_num(self.C * self.V)
        cs = np.vstack([np.zeros((1, K)), np.cumsum(val, axis=0)])
        adv = np.zeros((D, K))
        for d in range(D):
            a = max(0, d - 19)
            adv[d] = (cs[d + 1] - cs[a]) / 20.0
        self.ADV = adv
        self._ind = {}
        self._sig = {}
        self._regime_cache = {}
        self._own()

    # indikator per ticker pada deret barisnya sendiri
    def _own(self):
        self.own = []
        self.RSI = np.full((self.D, self.K), np.nan)
        self.ATR = np.full((self.D, self.K), np.nan)
        for k in range(self.K):
            idx = np.where(self.R[:, k])[0]
            c, h, l = self.C[idx, k], self.H[idx, k], self.L[idx, k]
            self.own.append(idx)
            n = len(idx)
            if n < 17:
                continue
            rsi = np.full(n, np.nan)
            g = ls = 0.0
            for i in range(1, 15):
                dd = c[i] - c[i - 1]
                g += dd if dd > 0 else 0
                ls += -dd if dd < 0 else 0
            g /= 14; ls /= 14
            rsi[14] = 100 if ls == 0 else 100 - 100 / (1 + g / ls)
            for i in range(15, n):
                dd = c[i] - c[i - 1]
                g = (g * 13 + (dd if dd > 0 else 0)) / 14
                ls = (ls * 13 + (-dd if dd < 0 else 0)) / 14
                rsi[i] = 100 if ls == 0 else 100 - 100 / (1 + g / ls)
            tr = np.maximum.reduce([h[1:] - l[1:], np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])])
            atr = np.full(n, np.nan)
            a = tr[:14].mean()
            atr[14] = a
            for i in range(15, n):
                a = (a * 13 + tr[i - 1]) / 14
                atr[i] = a
            self.RSI[idx, k] = rsi
            self.ATR[idx, k] = atr

    def ema(self, n):
        if n in self._ind:
            return self._ind[n]
        out = np.full((self.D, self.K), np.nan)
        k = 2.0 / (n + 1)
        for s in range(self.K):
            idx = self.own[s]
            if len(idx) == 0:
                continue
            c = self.C[idx, s]
            out[idx, s] = lfilter([k], [1, -(1 - k)], c, zi=[c[0] * (1 - k)])[0]
        self._ind[n] = out
        return out

    def signals(self, F, S):
        """matriks entry (D x K bool) dan peringkat gap EMA. Hanya memakai data <= t."""
        key = (F, S)
        if key in self._sig:
            return self._sig[key]
        f, sl = self.ema(F), self.ema(S)
        warm = S + 16
        ent = np.zeros((self.D, self.K), bool)
        gap = np.full((self.D, self.K), np.nan)
        for s in range(self.K):
            idx = self.own[s]
            n = len(idx)
            if n <= warm + 2:
                continue
            c = self.C[idx, s]; ff = f[idx, s]; ss = sl[idx, s]; r = self.RSI[idx, s]
            cross = np.zeros(n, bool)
            cross[1:] = (ff[1:] > ss[1:]) & (ff[:-1] <= ss[:-1])
            cu = np.zeros(n, bool)
            for k in range(5):
                cu[k:] |= cross[:n - k]
            mx = np.full(n, np.nan)
            if n > 56:
                w = np.lib.stride_tricks.sliding_window_view(c, 55)      # w[j] = c[j..j+54]
                mx[55:] = w[:n - 55].max(axis=1)                         # max c[i-55..i-1]
            A = cu & (r >= 50) & (r <= 75) & (c > ss)
            B = (c > ff) & (r >= 55) & (r <= 75) & (c > mx)
            e = (ff > ss) & (A | B)
            e[:warm] = False
            ent[idx, s] = e
            gap[idx, s] = (ff - ss) / ss
        self._sig[key] = (ent, gap)
        return ent, gap


# --------------------------------------------------------------------------- engine
def run(P, F=30, S=50, M=3.0, fee_mult=1.0, spread_ticks=1, delay=0, uni=None,
        entry_override=None, start_day=0, max_day=None, regime=0):
    """Jalankan backtest. Mengembalikan dict: eq (D,), trades, open, pending dsb."""
    D, K = P.D, P.K
    if max_day is not None:
        D = max_day + 1
    f, sl = P.ema(F), P.ema(S)
    ent, gap = P.signals(F, S)
    if entry_override is not None:
        ent, gap = entry_override
    if regime:
        ent = ent & market_regime(P, regime)[:, None]
    allowed = np.ones(K, bool) if uni is None else np.isin(np.arange(K), uni)
    bf, sf = BUY_FEE * fee_mult, SELL_FEE * fee_mult
    cash = CAP
    prev_eq = CAP
    pos = []                      # posisi terbuka
    held = {}
    pend_exit = {}                # s -> (due, alasan)
    pend_ent = {}                 # due -> [s...]
    eq = np.full(D, CAP)
    trades = []
    lastd = D - 1
    for d in range(D):
        # ---------------- OPEN: eksekusi order yang diputuskan pada close sebelumnya
        if d > 0:
            for p in list(pos):
                s = p['s']
                pe = pend_exit.get(s)
                if pe is None or pe[0] > d:
                    continue
                if not P.TR[d, s] or P.lock_dn[d, s]:
                    continue                                        # tidak bisa jual hari ini
                o = rtick(P.O[d, s])
                px = max(1, o - tick_dn(o) * spread_ticks)
                maxlots = int(LIQ * P.ADV[d - 1, s] // (px * 100))
                lots = min(p['sh'] // 100, maxlots)
                if lots < 1:
                    continue
                sh = lots * 100
                gross = sh * px
                fee = gross * sf
                p['proc'] += gross - fee
                p['fee'] += fee
                p['spr'] += sh * (o - px)
                p['xv'] += gross
                p['xsh'] += sh
                p['sh'] -= sh
                cash += gross - fee
                p['xfills'] += 1
                p['xlast'] = d
                if p['sh'] == 0:
                    pnl = p['proc'] - p['cost']
                    trades.append(dict(
                        tk=P.tk[s], s=s, sig=p['sig'], ei=p['ei'], xi=d, ep=p['px'], xp=p['xv'] / p['xsh'],
                        sh=p['sh0'], cost=p['cost'], proc=p['proc'], pnl=pnl, pct=pnl / p['cost'] * 100,
                        fee=p['fee'], spr=p['spr'], gross=pnl + p['fee'] + p['spr'], why=pe[1],
                        fills=p['xfills'], eqe=p['eqe']))
                    pos.remove(p)
                    del held[s]
                    del pend_exit[s]
            # entries
            cands = pend_ent.pop(d, [])
            for s in cands:
                if len(pos) >= MAXP:
                    break
                if s in held or not allowed[s]:
                    continue
                if not P.TR[d, s] or P.lock_up[d, s]:
                    continue
                o = rtick(P.O[d, s])
                px = o + tick(o) * spread_ticks
                alloc = min(cash, prev_eq / MAXP)
                lots = int(alloc // (px * 100 * (1 + bf)))
                lots = min(lots, int(LIQ * P.ADV[d - 1, s] // (px * 100)))
                if lots < 1:
                    continue
                sh = lots * 100
                gross = sh * px
                fee = gross * bf
                cash -= gross + fee
                p = dict(s=s, sh=sh, sh0=sh, px=px, cost=gross + fee, proc=0.0, fee=fee, spr=sh * (px - o), xv=0.0,
                         xsh=0, xfills=0, xlast=d, ei=d, sig=d - 1 - delay, hi=px, eqe=prev_eq)
                pos.append(p)
                held[s] = p
        # ---------------- CLOSE: mark-to-market, sinyal untuk bar berikutnya
        e = cash
        for p in pos:
            s = p['s']
            c = P.Cf[d, s]
            e += p['sh'] * c
            p['hi'] = max(p['hi'], c)
            if s not in pend_exit and P.R[d, s]:
                if c < p['hi'] - M * P.ATR[d, s]:
                    pend_exit[s] = (d + 1 + delay, 'ATR STOP')
                elif f[d, s] < sl[d, s]:
                    pend_exit[s] = (d + 1 + delay, 'EMA CROSS')
        eq[d] = e
        prev_eq = e
        if d >= start_day and len(pos) < MAXP and d < lastd:
            m = ent[d] & allowed
            if m.any():
                cs = [s for s in np.where(m)[0] if s not in held]
                cs.sort(key=lambda s: -gap[d, s])
                if cs:
                    pend_ent[d + 1 + delay] = cs
    open_pos = []
    for p in pos:
        s = p['s']
        c = P.Cf[lastd, s]
        open_pos.append(dict(tk=P.tk[s], s=s, ei=p['ei'], ep=p['px'], last=c, sh=p['sh'], sh0=p['sh0'],
                             cost=p['cost'], value=p['sh'] * c + p['proc'], pnl=p['sh'] * c + p['proc'] - p['cost'],
                             pct=(p['sh'] * c + p['proc'] - p['cost']) / p['cost'] * 100, stop=p['hi'] - M * P.ATR[lastd, s],
                             hi=p['hi'], pend=pend_exit.get(s, (None, None))[1]))
    return dict(eq=eq, trades=trades, open=open_pos, F=F, S=S, M=M, D=D)


# --------------------------------------------------------------------------- metrik
def month_ends(P, D):
    """indeks hari terakhir tiap bulan kalender (dalam data)."""
    ym = [d[:7] for d in P.dates[:D]]
    return [i for i in range(D) if i == D - 1 or ym[i + 1] != ym[i]], ym


def monthly_returns(P, eq):
    D = len(eq)
    me, ym = month_ends(P, D)
    out, prev = [], CAP
    for i in me:
        out.append((ym[i], eq[i] / prev - 1))
        prev = eq[i]
    return out, me


def metrics(P, res, rf_annual=0.0, lo=0, hi=None, bench=None):
    """semua metrik wajib & tambahan, sesudah biaya. lo/hi: potong periode (indeks hari)."""
    eq = res['eq']
    hi = len(eq) if hi is None else hi
    base = eq[lo - 1] if lo > 0 else CAP
    e = eq[lo:hi]
    trades = [t for t in res['trades'] if lo <= t['xi'] < hi]
    days = P.epoch[hi - 1] - (P.epoch[lo - 1] if lo > 0 else P.epoch[0])
    yrs = max(days, 1) / 365.25
    fin = e[-1]
    cagr = (fin / base) ** (1 / yrs) - 1
    pk = np.maximum.accumulate(np.r_[base, e])
    dd = np.r_[base, e] / pk - 1
    mdd = dd.min()
    W = [t for t in trades if t['pnl'] > 0]
    L = [t for t in trades if t['pnl'] <= 0]
    n = len(trades)
    wr = len(W) / n if n else float('nan')
    avgw = np.mean([t['pct'] for t in W]) if W else float('nan')
    avgl = np.mean([t['pct'] for t in L]) if L else float('nan')
    gw = sum(t['pnl'] for t in W)
    gl = -sum(t['pnl'] for t in L)
    pf = gw / gl if gl > 0 else float('inf')
    # bulanan
    ym = [d[:7] for d in P.dates[lo:hi]]
    me = [i for i in range(len(e)) if i == len(e) - 1 or ym[i + 1] != ym[i]]
    mr, prev, mpk, rec, gap, mgap, nrec = [], base, base, 0, 0, 0, 0
    for i in me:
        r = e[i] / prev - 1
        mr.append(r)
        if e[i] >= mpk:
            mpk = e[i]; rec += 1; gap = 0
        else:
            gap += 1; mgap = max(mgap, gap)
        prev = e[i]
    mr = np.array(mr)
    mu, sd = mr.mean(), mr.std(ddof=1) if len(mr) > 1 else float('nan')
    rfm = rf_annual / 12
    sharpe = (mu - rfm) / sd * math.sqrt(12) if sd and sd > 0 else float('nan')
    dsd = math.sqrt(np.mean(np.minimum(mr - rfm, 0) ** 2))
    sortino = (mu - rfm) / dsd * math.sqrt(12) if dsd > 0 else float('nan')
    exp = wr * avgw + (1 - wr) * avgl if n and W and L else float('nan')
    # exposure
    inv = np.zeros(len(e))
    npos = np.zeros(len(e))
    # dihitung dari res['inv'] bila ada
    if 'inv' in res:
        inv = res['inv'][lo:hi]; npos = res['npos'][lo:hi]
    hold = [(t['xi'] - t['ei']) for t in trades]
    hold_cal = [int(P.epoch[t['xi']] - P.epoch[t['ei']]) for t in trades]
    # kekalahan beruntun
    ts = sorted(trades, key=lambda t: (t['xi'], t['ei']))
    mls = cur = 0
    for t in ts:
        if t['pnl'] <= 0:
            cur += 1; mls = max(mls, cur)
        else:
            cur = 0
    net = sum(t['pnl'] for t in trades)
    top10 = sorted((t['pnl'] for t in trades), reverse=True)[:10]
    gross_all = sum(t['gross'] for t in trades)
    costs = sum(t['fee'] + t['spr'] for t in trades)
    return dict(
        n=n, cagr=cagr, wr=wr, avgw=avgw, avgl=avgl,
        avgw_rp=np.mean([t['pnl'] for t in W]) if W else float('nan'),
        avgl_rp=np.mean([t['pnl'] for t in L]) if L else float('nan'),
        pf=pf, gw=gw, gl=gl, rec_pct=rec / len(me), months=len(me), rec=rec, mdd=mdd, mgap=mgap,
        per_year=n / yrs, hold_bars=np.mean(hold) if hold else float('nan'),
        hold_days=np.mean(hold_cal) if hold_cal else float('nan'), exp=exp,
        payoff=avgw / abs(avgl) if W and L else float('nan'), sharpe=sharpe, sortino=sortino,
        calmar=cagr / abs(mdd) if mdd < 0 else float('nan'), final=fin, base=base, net_eq=fin - base,
        ret=fin / base - 1, yrs=yrs, mls=mls, net_trades=net,
        top10=sum(top10), top10_share=sum(top10) / net if net > 0 else float('nan'),
        fees=sum(t['fee'] for t in trades), spread=sum(t['spr'] for t in trades), costs=costs,
        gross_pnl=gross_all, cost_share=costs / gross_all if gross_all > 0 else float('nan'),
        exposure_days=float((npos > 0).mean()) if len(npos) else float('nan'),
        exposure_cap=float((inv / e).mean()) if len(inv) else float('nan'),
        sharpe_rf=sharpe, rf=rf_annual)


def exposure_series(P, res):
    """persentase hari dengan posisi terbuka & porsi modal terpakai, dari log trade (entry..exit)."""
    D = len(res['eq'])
    npos = np.zeros(D)
    inv = np.zeros(D)
    for t in res['trades']:
        # nilai posisi dihitung ulang pada close tiap hari saat dipegang
        a, b = t['ei'], t['xi']
        npos[a:b] += 1
        inv[a:b] += t['sh'] * P.Cf[a:b, t['s']]
    for o in res['open']:
        a = o['ei']
        npos[a:] += 1
        inv[a:] += o['sh0'] * P.Cf[a:, o['s']]
    res['npos'], res['inv'] = npos, inv
    return res


def annual_returns(P, eq):
    out, prev = {}, CAP
    yrs = [d[:4] for d in P.dates[:len(eq)]]
    for i in range(len(eq)):
        if i == len(eq) - 1 or yrs[i + 1] != yrs[i]:
            out[yrs[i]] = eq[i] / prev - 1
            prev = eq[i]
    return out


def benchmark(P, rebalance_monthly=True):
    """Pembanding beli-dan-tahan: equal-weight seluruh saham Kompas100 yang sudah listing,
    rebalancing bulanan tanpa biaya. (IHSG/LQ45 tidak ada di berkas data.)"""
    D, K = P.D, P.K
    out = np.full(D, CAP)
    w = np.zeros(K)                       # nilai per saham
    v = CAP
    ym = [d[:7] for d in P.dates]
    for d in range(1, D):
        # return harian tiap saham (memakai close ter-fill)
        prev, cur = P.Cf[d - 1], P.Cf[d]
        ok = ~np.isnan(prev) & ~np.isnan(cur)
        if rebalance_monthly and ym[d] != ym[d - 1] or d == 1:
            act = ~np.isnan(prev)
            v = (w.sum() if w.sum() > 0 else CAP)
            w = np.zeros(K)
            if act.any():
                w[act] = v / act.sum()
        r = np.zeros(K)
        r[ok] = cur[ok] / prev[ok] - 1
        w = w * (1 + r)
        out[d] = w.sum() if w.sum() > 0 else out[d - 1]
        # saham yang baru listing masuk pada rebalancing bulan berikutnya
    return out


def market_regime(P, period):
    """True when the equal-weight benchmark close is above its trailing SMA."""
    if period < 1:
        raise ValueError('Regime period must be a positive number of sessions')
    if period not in P._regime_cache:
        regime = np.zeros(P.D, dtype=bool)
        if period <= P.D:
            bench = benchmark(P)
            cumulative = np.r_[0.0, np.cumsum(bench)]
            average = (cumulative[period:] - cumulative[:-period]) / period
            regime[period - 1:] = bench[period - 1:] > average
        P._regime_cache[period] = regime
    return P._regime_cache[period]


def bench_metrics(P, b):
    yrs = (P.epoch[-1] - P.epoch[0]) / 365.25
    pk = np.maximum.accumulate(b)
    return dict(cagr=(b[-1] / b[0]) ** (1 / yrs) - 1, mdd=(b / pk - 1).min(), final=b[-1])


def sub_metrics(P, res, lo, hi):
    return metrics(P, exposure_series(P, res) if 'inv' not in res else res, lo=lo, hi=hi)
