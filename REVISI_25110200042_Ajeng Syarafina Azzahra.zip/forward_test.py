#!/usr/bin/env python3
"""
forward_test.py - paper trading strategi BEKU pada data SESUDAH tanggal pembekuan.
Pemakaian:  python forward_test.py <data_terbaru.json> [2026-10-29] [forward.json]
  data_terbaru.json : format sama dengan data backtest, tetapi memuat candle sesudah tanggal pembekuan
  hasil             : forward.json (kurva ekuitas harian, log trade, posisi terbuka, metrik) -
                      lalu jalankan:  python build_dashboard.py results.json forward.json <output.html>
Aturan & parameter TIDAK diubah: EMA 30/100, ATR 3x, SMA 200 rezim pasar, modal Rp100 juta, maks 10 posisi.
Indikator memakai seluruh riwayat sampai t (tanpa look-ahead); posisi baru hanya dibuka dari sinyal
close pada/ sesudah tanggal pembekuan. Forward test minimal 4 minggu (28 hari kalender).
"""
import sys, json, math
import numpy as np
import backtest as B

SRC = sys.argv[1]
FREEZE = sys.argv[2] if len(sys.argv) > 2 else '2026-10-29'
OUT = sys.argv[3] if len(sys.argv) > 3 else 'forward.json'
FROZEN = dict(F=30, S=100, M=3.0, regime=200)
P = B.Data(SRC)
fi = max(i for i, d in enumerate(P.dates) if d <= FREEZE) if P.dates[0] <= FREEZE else None
if fi is None or fi >= P.D - 1:
    print('Belum ada data sesudah tanggal pembekuan %s (candle terakhir %s). Tidak ada forward test.' % (FREEZE, P.dates[-1]))
    sys.exit(1)
res = B.exposure_series(P, B.run(P, **FROZEN, start_day=fi))
eq = res['eq'][fi:]
dates = P.dates[fi:]
days = int(P.epoch[-1] - P.epoch[fi])
trades = [t for t in res['trades']]
bench = B.benchmark(P)[fi:]
bench = bench / bench[0] * B.CAP
pk = np.maximum.accumulate(eq)
out = dict(freeze=FREEZE, first=dates[0], last=dates[-1], days=days, weeks=days / 7.0, ok_min_4w=days >= 28,
           dates=dates, equity=[round(float(x), 2) for x in eq], bench=[round(float(x), 2) for x in bench],
           ret=float(eq[-1] / B.CAP - 1), mdd=float((eq / pk - 1).min()), bench_ret=float(bench[-1] / B.CAP - 1),
           trades=[dict(tk=t['tk'], ed=P.dates[t['ei']], xd=P.dates[t['xi']], ep=t['ep'], xp=round(t['xp'], 2), lots=t['sh'] // 100,
                        pnl=round(t['pnl'], 2), pct=round(t['pct'], 4), why=t['why']) for t in trades if t['ei'] > fi],
           open=[dict(tk=o['tk'], ed=P.dates[o['ei']], ep=o['ep'], last=o['last'], lots=o['sh0'] // 100, pct=round(o['pct'], 3),
                      pnl=round(o['pnl'], 2)) for o in res['open']])
json.dump(out, open(OUT, 'w'), separators=(',', ':'))
print('forward test %s .. %s (%.1f minggu): return %.2f%%, MDD %.2f%%, %d trade tertutup, %d posisi terbuka%s' % (
    dates[0], dates[-1], days / 7, out['ret'] * 100, out['mdd'] * 100, len(out['trades']), len(out['open']),
    '' if out['ok_min_4w'] else '  [BELUM 4 MINGGU]'))
