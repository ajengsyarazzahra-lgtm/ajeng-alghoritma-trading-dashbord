#!/usr/bin/env python3
"""build_dashboard.py - menanam results.json (dan opsional forward.json) ke dashboard_template.html
Pemakaian: python build_dashboard.py results.json [forward.json] output.html"""
import sys, json, os
a = [x for x in sys.argv[1:]]
res = json.load(open(a[0]))
fw = None
out = a[-1]
if len(a) == 3:
    fw = json.load(open(a[1]))
    res['forward'] = fw
here = os.path.dirname(os.path.abspath(__file__))
tpl = open(os.path.join(here, 'dashboard_template.html'), encoding='utf-8').read()
blob = json.dumps(res, separators=(',', ':'), ensure_ascii=False).replace('</', '<\\/')
assert '/*__DATA__*/' in tpl
html = tpl.replace('/*__DATA__*/', blob)
open(out, 'w', encoding='utf-8').write(html)
print('ditulis %s (%.2f MB)' % (out, os.path.getsize(out) / 1e6))
