#!/usr/bin/env python3
"""Select strategy parameters on an early training window and report a later holdout."""
import itertools
import json
import sys

import backtest as B

SRC = sys.argv[1] if len(sys.argv) > 1 else 'kompas100_10thn.json'
P = B.Data(SRC)
span = P.epoch[-1] - P.epoch[0]
cut = int(next(i for i, day in enumerate(P.epoch) if day >= P.epoch[0] + 0.85 * span))

candidates = []
for F, S, M, regime in itertools.product(
        (20, 30, 40), (50, 75, 100), (2.0, 3.0, 4.0), (0, 100, 150, 200)):
    if F >= S:
        continue
    result = B.run(P, F, S, M, regime=regime)
    train = B.metrics(P, result, hi=cut)
    test = B.metrics(P, result, lo=cut)
    candidates.append(dict(
        F=F, S=S, M=M, regime=regime,
        train_cagr=train['cagr'], train_mdd=train['mdd'],
        train_calmar=train['calmar'], train_pf=train['pf'], train_n=train['n'],
        holdout_start=P.dates[cut], holdout_cagr=test['cagr'],
        holdout_mdd=test['mdd'], holdout_pf=test['pf'], holdout_n=test['n']))

eligible = [c for c in candidates if c['train_n'] >= 100
            and c['train_mdd'] >= -0.40 and c['train_pf'] > 1]
if not eligible:
    raise RuntimeError('No candidate met the training-sample risk constraints')
selected = max(eligible, key=lambda c: c['train_calmar'])

print(json.dumps(dict(
    selection='highest training Calmar; train trades >= 100, PF > 1, MDD >= -40%',
    candidates=len(candidates), train_end=P.dates[cut - 1],
    holdout_start=P.dates[cut], selected=selected,
    warning='Holdout is historical data, not a forward test; repeated research on this dataset can overfit.'
), indent=2))
