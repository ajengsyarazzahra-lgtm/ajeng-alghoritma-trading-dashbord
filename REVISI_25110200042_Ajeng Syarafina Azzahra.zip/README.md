# Kode sumber backtest – UTS Algorithmic Trading
Ajeng Syarafina Azzahra · NIM 25110200042 · Prodi Finance and Investment

Strategi: EMA 30/100 crossover + RSI(14) + breakout 55 hari + trailing stop 3xATR(14), long-only, saham BEI Kompas100, harian. Entry hanya diizinkan saat benchmark equal-weight Kompas100 berada di atas SMA 200 hari.
Parameter dibekukan 29 Okt 2026 setelah pencarian historis 108 kandidat. Pencarian memilih rasio Calmar tertinggi pada 85% periode latih, dengan minimal 100 trade, profit factor > 1, dan max drawdown tidak lebih buruk dari -40%. Sisa 15% dilaporkan sebagai holdout historis, bukan forward test; pencarian banyak kandidat tetap berisiko overfit.

## Menjalankan di VS Code (live)
1. Buka folder ini di VS Code (File > Open Folder). Buka Terminal (Ctrl+`).
2. (Disarankan) buat virtual environment:
   - Windows: `python -m venv .venv` lalu `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv` lalu `source .venv/bin/activate`
3. `pip install -r requirements.txt` (Python 3.10+).
4. Letakkan data harga di folder ini, namanya `kompas100_10thn.json`, format:
   `{"data": {KODE: {"d":[hari-epoch],"o":[],"h":[],"l":[],"c":[],"v":[]}}}`
   (data tidak disertakan di zip; SHA-256 berkas tercantum di dashboard, tab Identitas & Aturan).
5. (Opsional) Ulangi pemilihan parameter historis:
   `python optimize_strategy.py kompas100_10thn.json`
   Hasil holdout hanya diagnostik historis dan tidak membuktikan performa masa depan.
6. Backtest utama + semua uji validitas (IS/OOS, walk-forward, sensitivitas, biaya 2x, delay 1 bar, truncation test, audit, bonus):
   `python validate.py kompas100_10thn.json results.json`
7. Bangun dashboard mandiri:
   `python build_dashboard.py results.json UTS_25110200042_AjengSyarafinaAzzahra.html`
   Klik dua kali file HTML untuk membukanya (tanpa server, tanpa internet).
8. Dosen dapat mengganti `kompas100_10thn.json` dengan data periode lain, lalu mengulang langkah 5-7.

## Forward test (setelah 26 Nov 2026)
Unduh data harian terbaru yang memuat candle sesudah 29 Okt 2026 (format JSON sama), lalu:
`python forward_test.py data_terbaru.json 2026-10-29 forward.json`
`python build_dashboard.py results.json forward.json UTS_25110200042_AjengSyarafinaAzzahra.html`
Forward test dilaporkan terpisah dari backtest dan tidak boleh mengubah aturan atau parameter.

## Berkas
- `backtest.py` mesin: sinyal, eksekusi BEI (fee 0,15/0,25%, spread 1 fraksi, fraksi harga, lot, likuiditas 5% ADV20, proksi ARA/ARB), metrik.
- `optimize_strategy.py` pencarian parameter yang hanya memakai metrik pada periode latih; holdout tidak ikut menentukan parameter.
- `validate.py` seluruh uji validitas, menulis `results.json`.
- `forward_test.py` paper trading strategi beku sesudah tanggal pembekuan.
- `build_dashboard.py` + `dashboard_template.html` menanam hasil ke HTML mandiri.
