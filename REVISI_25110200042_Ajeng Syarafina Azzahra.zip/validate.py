#!/usr/bin/env python3
"""
validate.py - menjalankan backtest utama + seluruh uji validitas (PDF bagian 6) dan menulis results.json
Pemakaian:  python validate.py <data.json> [results.json]
Backtest utama dijalankan satu kali dengan strategi beku dan filter rezim pasar.
"""
import sys, json, math, hashlib, time
import numpy as np
import backtest as B

FROZEN = dict(F=30, S=100, M=3.0, regime=200)
SRC = sys.argv[1] if len(sys.argv) > 1 else 'kompas100_10thn.json'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'results.json'
t0 = time.time()
P = B.Data(SRC)
D = P.D
COMBOS = set()
_cache = {}


def go(F, S, M, **kw):
    """satu run; kombinasi parameter yang dijalankan dicatat (untuk laporan jumlah kombinasi)."""
    kw.setdefault('regime', FROZEN['regime'])
    key = (F, S, M, tuple(sorted(kw.items())))
    if key not in _cache:
        COMBOS.add((F, S, round(M, 4)))
        r = B.run(P, F, S, M, **kw)
        _cache[key] = B.exposure_series(P, r)
    return _cache[key]


def clean(o):
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.floating, float)):
        o = float(o)
        return None if (math.isnan(o)) else ('Infinity' if math.isinf(o) else o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return o


def M_(res, **kw):
    return B.metrics(P, res, **kw)


def short(m):
    keys = ['n', 'cagr', 'mdd', 'pf', 'wr', 'sharpe', 'calmar', 'final', 'ret', 'avgw', 'avgl', 'exp', 'net_trades', 'cost_share']
    return {k: m[k] for k in keys}


# ------------------------------------------------------------------ 1. backtest utama (1 kali, parameter beku)
main = go(**FROZEN)
mm = M_(main)
mm_rf = M_(main, rf_annual=0.05)
bench = B.benchmark(P)
bm = B.bench_metrics(P, bench)
print('utama: trades', mm['n'], 'CAGR %.2f%% MDD %.2f%%' % (mm['cagr'] * 100, mm['mdd'] * 100), 'PF %.2f' % mm['pf'])

# ------------------------------------------------------------------ 2. biaya & keterlambatan
sc = {
    'before': go(**FROZEN, fee_mult=0.0, spread_ticks=0),
    'after': main,
    'x2': go(**FROZEN, fee_mult=2.0, spread_ticks=2),
    'delay': go(**FROZEN, delay=1),
}
scen = {k: M_(v) for k, v in sc.items()}

# ------------------------------------------------------------------ 3. IS / OOS 70/30 (berdasar waktu kalender)
span = P.epoch[-1] - P.epoch[0]
cut = int(np.argmax(P.epoch >= P.epoch[0] + 0.7 * span))
selection_cut = int(np.argmax(P.epoch >= P.epoch[0] + 0.85 * span))
IS = M_(main, lo=0, hi=cut)
OOS = M_(main, lo=cut, hi=D)
bIS = (bench[cut - 1] / bench[0]) ** (365.25 / (P.epoch[cut - 1] - P.epoch[0])) - 1
bOOS = (bench[-1] / bench[cut - 1]) ** (365.25 / (P.epoch[-1] - P.epoch[cut - 1])) - 1


def bdd(lo, hi):
    b = bench[lo:hi]
    return float((b / np.maximum.accumulate(np.r_[bench[lo - 1] if lo else bench[0], b])[1:] - 1).min())


# ------------------------------------------------------------------ 4. walk-forward (6 jendela, 5 pasangan latih->uji)
NW = 6
edges = [0] + [int(np.argmax(P.epoch >= P.epoch[0] + span * k / NW)) for k in range(1, NW)] + [D]
CANDS = [(f, s, m) for f in (20, 30, 40) for s in (50, 75, 100) for m in (2.0, 3.0, 4.0) if f < s]


def seg_ret(res, lo, hi):
    base = res['eq'][lo - 1] if lo > 0 else B.CAP
    return float(res['eq'][hi - 1] / base - 1)


wf = []
chain = [1.0]
wf_dates = []
fix_chain = [1.0]
for k in range(NW - 1):
    a, b, c = edges[k], edges[k + 1], edges[k + 2]
    sc_ = [(seg_ret(go(f, s, m), a, b), (f, s, m)) for (f, s, m) in CANDS]
    best = max(sc_, key=lambda x: x[0])
    f, s, m = best[1]
    tr = go(f, s, m)
    base = tr['eq'][b - 1]
    for i in range(b, c):
        chain.append(chain[0] * 0 + chain[-1] * (tr['eq'][i] / tr['eq'][i - 1]))
        fix_chain.append(fix_chain[-1] * (main['eq'][i] / main['eq'][i - 1]))
        wf_dates.append(i)
    wf.append(dict(win_train=[P.dates[a], P.dates[b - 1]], win_test=[P.dates[b], P.dates[c - 1]], params=[f, s, m],
                   train_ret=best[0], test_ret=seg_ret(tr, b, c),
                   test_mdd=float(B.metrics(P, tr, lo=b, hi=c)['mdd']),
                   fixed_test_ret=seg_ret(main, b, c),
                   bench_test_ret=float(bench[c - 1] / bench[b - 1] - 1),
                   n_cands=len(CANDS)))
wf_curve = [x * B.CAP for x in chain[1:]]
wf_fix = [x * B.CAP for x in fix_chain[1:]]
wf_total = chain[-1] - 1
yrs_wf = (P.epoch[D - 1] - P.epoch[edges[1] - 1]) / 365.25
wf_cagr = chain[-1] ** (1 / yrs_wf) - 1
wpk = np.maximum.accumulate(np.r_[1.0, chain[1:]])
wf_mdd = float((np.r_[1.0, chain[1:]] / wpk - 1).min())
wf_summary = dict(total=wf_total, cagr=wf_cagr, mdd=wf_mdd, positive_windows=sum(1 for w in wf if w['test_ret'] > 0),
                  windows=len(wf), fixed_total=fix_chain[-1] - 1, dates=[P.dates[i] for i in wf_dates][::1],
                  start=P.dates[edges[1]], edges=[P.dates[e] for e in edges[:-1]] + [P.dates[-1]])

# ------------------------------------------------------------------ 5. sensitivitas parameter
F0, S0, M0 = FROZEN['F'], FROZEN['S'], FROZEN['M']
mult = [0.5, 0.8, 1.0, 1.2, 1.5]
sens = []
for name, base, kind in (('Fast EMA', F0, 'F'), ('Slow EMA', S0, 'S'), ('ATR stop (x)', M0, 'M')):
    row = dict(param=name, base=base, cells=[])
    for k in mult:
        v = base * k
        v = round(v) if kind in 'FS' else round(v, 2)
        p = dict(F=F0, S=S0, M=M0)
        p[kind] = v
        if not p['F'] < p['S']:
            row['cells'].append(dict(mult=k, value=v, na=True))
            continue
        m = M_(go(p['F'], p['S'], p['M']))
        row['cells'].append(dict(mult=k, value=v, na=False, cagr=m['cagr'], mdd=m['mdd'], pf=m['pf'], n=m['n']))
    sens.append(row)
heatFS = dict(rows=[15, 20, 25, 30, 35, 40, 45], cols=[40, 50, 60, 75, 100], cells=[])
for f in heatFS['rows']:
    heatFS['cells'].append([])
    for s in heatFS['cols']:
        if f >= s:
            heatFS['cells'][-1].append(None)
        else:
            m = M_(go(f, s, M0))
            heatFS['cells'][-1].append(dict(cagr=m['cagr'], mdd=m['mdd'], n=m['n']))
heatMS = dict(rows=[1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5], cols=[40, 50, 60, 75, 100], cells=[])
for mv in heatMS['rows']:
    heatMS['cells'].append([])
    for s in heatMS['cols']:
        m = M_(go(F0, s, mv))
        heatMS['cells'][-1].append(dict(cagr=m['cagr'], mdd=m['mdd'], n=m['n']))
neigh = [c for r in sens for c in r['cells'] if not c['na'] and c['mult'] != 1.0]
plateau = dict(neighbors=len(neigh), positive=sum(1 for c in neigh if c['cagr'] > 0),
               min=min(c['cagr'] for c in neigh), max=max(c['cagr'] for c in neigh),
               nan=sum(1 for r in sens for c in r['cells'] if c['na']))

# ------------------------------------------------------------------ 6. ketahanan
tr_sorted = sorted(main['trades'], key=lambda t: -t['pnl'])
top5 = sum(t['pnl'] for t in tr_sorted[:5])
top1 = tr_sorted[0]['pnl']
yrs = (P.epoch[-1] - P.epoch[0]) / 365.25
ann = B.annual_returns(P, main['eq'])
fin_ex5 = mm['final'] - top5
robust = dict(top5=top5, top5_list=[dict(tk=t['tk'], ed=P.dates[t['ei']], xd=P.dates[t['xi']], pnl=t['pnl'], pct=t['pct']) for t in tr_sorted[:5]],
              net_profit=mm['final'] - B.CAP, net_ex5=fin_ex5 - B.CAP, cagr_ex5=(max(fin_ex5, 1) / B.CAP) ** (1 / yrs) - 1,
              top1_share=top1 / (mm['final'] - B.CAP) if mm['final'] > B.CAP else None,
              loss_years=[y for y, v in ann.items() if v < 0], n_years=len(ann), ann={k: float(v) for k, v in ann.items()})
# tanpa 5 trade terbaik sebagai kurva: hasil net dihitung dari log (aproksimasi: pnl rupiah dikurangi)

# ------------------------------------------------------------------ 7. bonus: Monte Carlo bootstrap urutan trade
rng = np.random.default_rng(20261029)
pct = np.array([t['pct'] / 100 for t in main['trades']])
frac = float(np.mean([t['cost'] / t['eqe'] for t in main['trades']]))
sims = 2000
cg, md = [], []
n = len(pct)
for _ in range(sims):
    x = rng.choice(pct, n, replace=True)
    e = np.cumprod(1 + frac * x)
    e = np.r_[1.0, e]
    cg.append(e[-1] ** (1 / yrs) - 1)
    md.append((e / np.maximum.accumulate(e) - 1).min())
mc = dict(sims=sims, frac=frac, cagr_p5=float(np.percentile(cg, 5)), cagr_p50=float(np.percentile(cg, 50)),
          cagr_p95=float(np.percentile(cg, 95)), mdd_p5=float(np.percentile(md, 5)), mdd_p50=float(np.percentile(md, 50)),
          prob_loss=float(np.mean(np.array(cg) < 0)))

# ------------------------------------------------------------------ 8. bonus: entri acak (filter tren saja) & separuh universe
f_, sl_ = P.ema(F0), P.ema(S0)
regime_filter = B.market_regime(P, FROZEN['regime'])
elig = P.TR & (f_ > sl_) & regime_filter[:, None]
elig[:S0 + 16] = False


def rand_run(p, seed):
    r = np.random.default_rng(seed)
    m = (r.random((D, P.K)) < p) & elig
    g = r.random((D, P.K))
    return B.run(P, F0, S0, M0, entry_override=(m, g), regime=FROZEN['regime'])


p = 0.004
for _ in range(3):
    ns = np.mean([len(rand_run(p, s)['trades']) for s in range(3)])
    p *= mm['n'] / ns
rnd = []
for s in range(30):
    rr = B.exposure_series(P, rand_run(p, 100 + s))
    m = M_(rr)
    rnd.append((m['cagr'], m['mdd'], m['n'], m['pf']))
rnd = np.array(rnd)
rand = dict(runs=len(rnd), p=p, trades_mean=float(rnd[:, 2].mean()), cagr_mean=float(rnd[:, 0].mean()),
            cagr_p5=float(np.percentile(rnd[:, 0], 5)), cagr_p50=float(np.percentile(rnd[:, 0], 50)),
            cagr_p95=float(np.percentile(rnd[:, 0], 95)), mdd_mean=float(rnd[:, 1].mean()),
            pf_mean=float(rnd[:, 3].mean()), rank=float((rnd[:, 0] < mm['cagr']).mean()))
odd = list(range(0, P.K, 2))
even = list(range(1, P.K, 2))
halves = {}
for nm, u in (('Separuh A (indeks genap)', odd), ('Separuh B (indeks ganjil)', even)):
    r_ = B.exposure_series(P, B.run(P, F0, S0, M0, uni=u, regime=FROZEN['regime']))
    halves[nm] = short(M_(r_))
    halves[nm]['tickers'] = len(u)

# ------------------------------------------------------------------ 9. uji look-ahead: pemotongan data (truncation test)
trunc = []
for frac_ in (0.55, 0.75, 0.9):
    cd = int(D * frac_)
    P2 = B.Data(SRC, max_day=int(P.epoch[cd]))
    r2 = B.run(P2, F0, S0, M0, regime=FROZEN['regime'])
    full_e = {(t['tk'], t['ei']): t for t in main['trades'] if t['ei'] <= cd}
    full_x = {(t['tk'], t['ei']): t for t in main['trades'] if t['xi'] <= cd}
    tr_e = {(t['tk'], t['ei']): t for t in r2['trades'] if t['ei'] <= cd}
    open_e = {(o['tk'], o['ei']): o for o in r2['open'] if o['ei'] <= cd}
    allk = set(tr_e) | set(open_e)
    ent_match = allk == set(full_e) and all(abs((tr_e.get(k) or open_e.get(k))['ep'] - full_e[k]['ep']) < 1e-9 for k in full_e if k in allk)
    ex_match = all(k in tr_e and tr_e[k]['xi'] == full_x[k]['xi'] and abs(tr_e[k]['xp'] - full_x[k]['xp']) < 1e-9 for k in full_x)
    eq_match = bool(np.allclose(r2['eq'][:cd + 1], main['eq'][:cd + 1], rtol=0, atol=1e-6))
    trunc.append(dict(cut=P.dates[cd], entries=len(full_e), exits=len(full_x), entries_ok=bool(ent_match), exits_ok=bool(ex_match),
                      equity_ok=eq_match))

# ------------------------------------------------------------------ 10. audit eksekusi independen dari log trade
aud = dict(n=len(main['trades']), checks={})


def chk(name, ok_list):
    aud['checks'][name] = dict(ok=int(sum(ok_list)), n=len(ok_list))


T = main['trades']
chk('Entry diisi paling cepat di bar setelah sinyal', [t['ei'] >= t['sig'] + 1 for t in T])
chk('Hari entry punya baris data & volume > 0', [bool(P.TR[t['ei'], t['s']]) for t in T])
chk('Entry tidak terjadi saat ARA terkunci (proksi)', [not bool(P.lock_up[t['ei'], t['s']]) for t in T])
chk('Exit terakhir pada hari bervolume > 0 & tidak ARB terkunci', [bool(P.TR[t['xi'], t['s']]) and not bool(P.lock_dn[t['xi'], t['s']]) for t in T])
chk('Harga entry = open dibulatkan fraksi + 1 fraksi (offer)', [abs(t['ep'] - (B.rtick(P.O[t['ei'], t['s']]) + B.tick(B.rtick(P.O[t['ei'], t['s']])))) < 1e-9 for t in T])
chk('Jumlah saham kelipatan 100 (1 lot)', [t['sh'] % 100 == 0 for t in T])
chk('Nilai order entry <= 5% rata-rata nilai transaksi 20 hari (s.d. t-1)', [t['sh'] * t['ep'] <= 0.05 * P.ADV[t['ei'] - 1, t['s']] + 1e-6 for t in T])
chk('Hasil trade = proceeds - biaya perolehan (dihitung ulang)', [abs(t['pnl'] - (t['proc'] - t['cost'])) < 1e-6 for t in T])
chk('Fee beli 0,15% & jual 0,25% sesuai nilai transaksi', [abs(t['fee'] - (t['sh'] * t['ep'] * B.BUY_FEE + (t['proc'] and t['sh'] * t['xp'] * B.SELL_FEE))) < 1e-4 * max(1, t['sh'] * t['ep']) for t in T])
chk('Entry setelah hari ke (S+16) pemanasan indikator', [True if t['sig'] >= 0 else False for t in T])
chk('Maksimal 10 posisi bersamaan', [True])
mx = 0
ev = np.zeros(D + 1)
for t in T:
    ev[t['ei']] += 1; ev[t['xi']] -= 1
for o in main['open']:
    ev[o['ei']] += 1
mx = int(np.cumsum(ev).max())
aud['max_concurrent'] = mx
aud['checks']['Maksimal 10 posisi bersamaan'] = dict(ok=int(mx <= 10), n=1)

# ------------------------------------------------------------------ 11. tanda bahaya
flags = []
flags.append(dict(name='CAGR jangka panjang > 100%/tahun', hit=mm['cagr'] > 1, val='%.1f%%' % (mm['cagr'] * 100)))
flags.append(dict(name='Win ratio > 80% dengan avg loss sangat kecil', hit=mm['wr'] > .8, val='%.1f%%' % (mm['wr'] * 100)))
flags.append(dict(name='Profit factor > 3', hit=mm['pf'] > 3, val='%.2f' % mm['pf']))
flags.append(dict(name='Kurva ekuitas hampir lurus tanpa drawdown berarti', hit=mm['mdd'] > -0.05, val='MDD %.1f%%' % (mm['mdd'] * 100)))
flags.append(dict(name='Out-of-sample jauh lebih baik daripada in-sample', hit=OOS['cagr'] > IS['cagr'] + 0.10, val='IS %.1f%% / OOS %.1f%%' % (IS['cagr'] * 100, OOS['cagr'] * 100)))
d_ = scen['delay']
flags.append(dict(name='Hasil runtuh (CAGR <= 0 atau turun lebih dari separuh) saat eksekusi ditunda 1 bar', hit=(d_['cagr'] <= 0 or d_['cagr'] < 0.5 * mm['cagr']), val='CAGR %.1f%% -> %.1f%%' % (mm['cagr'] * 100, d_['cagr'] * 100)))
flags.append(dict(name='Tidak ada satu pun tahun rugi', hit=len(robust['loss_years']) == 0, val='%d tahun rugi' % len(robust['loss_years'])))
share = (robust['top1_share'] or 0)
flags.append(dict(name='Sebagian besar laba berasal dari 1–2 trade', hit=share > 0.5, val='trade terbaik = %.0f%% dari laba bersih' % (share * 100)))

# ------------------------------------------------------------------ 12. susun hasil
def trade_row(t):
    return dict(tk=t['tk'], sd=P.dates[t['sig']], ed=P.dates[t['ei']], xd=P.dates[t['xi']], ep=t['ep'], xp=round(t['xp'], 2),
                lots=t['sh'] // 100, fee=round(t['fee'], 2), spr=round(t['spr'], 2), cost=round(t['cost'], 2),
                proc=round(t['proc'], 2), pnl=round(t['pnl'], 2), pct=round(t['pct'], 9), why=t['why'],
                bars=t['xi'] - t['ei'], days=int(P.epoch[t['xi']] - P.epoch[t['ei']]), fills=t['fills'])


res = dict(
    meta=dict(source=P.meta.get('source'), description=P.meta.get('description'), last_candle=P.meta.get('last_candle'),
              tickers=P.K, first=P.dates[0], last=P.dates[-1], days=D, sha256=hashlib.sha256(open(SRC, 'rb').read()).hexdigest(),
              file=SRC.split('/')[-1], zero_vol_rows=int((P.R & ~P.TR).sum()), lock_up=int(P.lock_up.sum()), lock_dn=int(P.lock_dn.sum()),
              warm=S0 + 16, cap=B.CAP, maxp=B.MAXP, frozen=FROZEN,
              strategy_selection=dict(method='training Calmar ratio', candidate_count=108,
                                      train_end=P.dates[selection_cut - 1], holdout_start=P.dates[selection_cut],
                                      min_train_trades=100, min_train_profit_factor=1.0,
                                      max_train_drawdown=-0.40,
                                      note='Historical holdout is not a forward test; selection on historical data may overfit.'),
              universe=P.tk),
    dates=P.dates,
    equity=[round(float(x), 2) for x in main['eq']],
    bench=[round(float(x), 2) for x in bench],
    bench_metrics=bm,
    metrics=mm, metrics_rf5=dict(sharpe=mm_rf['sharpe'], sortino=mm_rf['sortino']),
    trades=[trade_row(t) for t in main['trades']],
    open=[dict(tk=o['tk'], ed=P.dates[o['ei']], ep=o['ep'], last=o['last'], lots=o['sh0'] // 100, lots_now=o['sh'] // 100,
               pnl=round(o['pnl'], 2), pct=round(o['pct'], 3), cost=round(o['cost'], 2), stop=round(float(o['stop']), 1),
               value=round(o['value'], 2), pend=o['pend']) for o in main['open']],
    scenarios={k: dict(m=short(v), costs=dict(fees=v['fees'], spread=v['spread'], gross=v['gross_pnl'])) for k, v in scen.items()},
    scen_equity={k: [round(float(x), 2) for x in sc[k]['eq']] for k in ('before', 'x2', 'delay')},
    isoos=dict(cut=P.dates[cut], IS=IS, OOS=OOS, bench_is=bIS, bench_oos=bOOS, bench_mdd_is=bdd(1, cut), bench_mdd_oos=bdd(cut, D)),
    wf=wf, wf_curve=wf_curve, wf_fix=wf_fix, wf_summary=wf_summary, wf_cands=CANDS,
    sens=sens, heatFS=heatFS, heatMS=heatMS, plateau=plateau, robust=robust,
    mc=mc, rand=rand, halves=halves, trunc=trunc, audit=aud, flags=flags,
    npos=[int(x) for x in main['npos']], combos=len(COMBOS), combos_list=sorted(COMBOS),
    runtime=round(time.time() - t0, 1))
json.dump(clean(res), open(OUT, 'w'), separators=(',', ':'), allow_nan=False)
print('selesai %.1fs  kombinasi unik: %d  hasil -> %s' % (time.time() - t0, len(COMBOS), OUT))
